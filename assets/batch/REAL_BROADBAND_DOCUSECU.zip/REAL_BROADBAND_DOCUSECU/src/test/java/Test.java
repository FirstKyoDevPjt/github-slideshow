import imprt.infosec.jni.*;

public class Test {

	public static void main(String[] args)
	{
//		System.out.println(args[0]);
		
		SECGNApi sECGN = new SECGNApi();
		String sResult = sECGN.GetFileInfo1(args[0].getBytes());
		System.out.println(sResult);
	}
}
