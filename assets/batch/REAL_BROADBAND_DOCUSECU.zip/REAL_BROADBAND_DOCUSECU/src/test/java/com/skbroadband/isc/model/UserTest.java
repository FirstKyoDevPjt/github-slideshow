/*
 * Copyright 2003-2016 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.skbroadband.isc.model;

import static org.hamcrest.CoreMatchers.*;
//import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.MatcherAssert.assertThat;

//import lombok.extern.slf4j.Slf4j;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.BasePasswordEncoder;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.security.authentication.encoding.ShaPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

//import org.springframework.test.annotation.Rollback;
//import org.springframework.test.context.ActiveProfiles;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//import org.springframework.test.context.transaction.AfterTransaction;
//import org.springframework.test.context.transaction.BeforeTransaction;
import org.springframework.transaction.annotation.Transactional;

import com.skbroadband.edds.configration.ApplicationContext;
import com.skbroadband.edds.configration.DatabaseContext;
import com.skbroadband.edds.configration.SecurityContext;

import lombok.extern.slf4j.Slf4j;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

/**
 * @author andromediano
 *
 */
@Slf4j
@ActiveProfiles("development")
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {SecurityContext.class, ApplicationContext.class, DatabaseContext.class})
public class UserTest {

	
    @PersistenceContext(type = PersistenceContextType.EXTENDED)
    EntityManager entityManager;

    @Autowired
    PasswordEncoder passwordEncoder;
/*
    @BeforeTransaction
    public void beforeTransaction() throws Exception {
        log.info("@@ 트랜잭션을 시작합니다.");
    }

    @AfterTransaction
    public void afterTransaction() throws Exception {
        log.info("@@ 트랜잭션을 종료합니다.");
    }*/

    @Test
    @Ignore
    @Transactional
    public void testAddUser() throws Exception {

        /*
        assertNotNull(entityManager.find(Organization.class, 1L));
        assertNotNull(entityManager.find(Role.class, "ROLE_ADMIN"));
        assertNotNull(entityManager.find(Role.class, "ROLE_STEERING"));
        assertNotNull(entityManager.find(Role.class, "ROLE_USER"));
        */

        /*
        BasePasswordEncoder passwordEncoder = new Md5PasswordEncoder();

        User user = new User();
        user.setUserId("andromediano@gmail.com");
        user.setOrganization(entityManager.find(Organization.class, 1L));
        user.setUserNm("Daeyong Yang");
        user.setEnabled("Y");
        user.setPassword(passwordEncoder.encodePassword("111111", user.getUserId()));

        // 할당할 역할 세팅
        UserRole userRole1 = new UserRole(user, entityManager.find(Role.class, "ROLE_ADMIN"));
        UserRole userRole2 = new UserRole(user, entityManager.find(Role.class, "ROLE_STEERING"));
        UserRole userRole3 = new UserRole(user, entityManager.find(Role.class, "ROLE_USER"));

        // 사용자 역할 할당
        user.getUserRoles().add(userRole1);
        user.getUserRoles().add(userRole2);
        user.getUserRoles().add(userRole3);

        entityManager.persist(user);
        //log.info("password = {}", user.getPassword());
        */

    }

    @Test
    public void testGenerateEncodedPassword() throws Exception {

        // Given
        String password = "1234";

        // When
        //String encodedPassword = passwordEncoder.encode(password);
        
        
    	BasePasswordEncoder passwordEncoder2 = new ShaPasswordEncoder(256);
    	
		
 
        System.out.println(   	passwordEncoder2.encodePassword(password, "ADMIN"
        		+ ""
        		+ ""
        		+ ""));
        //log.debug("@: bcript encoded password = {}", new BCryptPasswordEncoder().encode(password));
        
        //log.debug("@: encoded password = {}", encodedPassword);
        //log.info("encoded password = {}", encodedPassword);
        //log.debug("@: encoded password = {}", encodedPassword);

        //log.debug("@: bcript encoded password = {}", new BCryptPasswordEncoder().encode(password));

        // Then
        //assertThat(encodedPassword, notNullValue());
    }

    
    @Test
    public void testBrCryptGenerateEncodedPassword() throws Exception {

        // Given
        String password = "1234";

        // When
      
        
        System.out.println("password : " + new BCryptPasswordEncoder().encode(password) );

        
       // String encodedPassword = passwordEncoder.encode(password);
  
        //log.debug("@: bcript encoded password = {}", new BCryptPasswordEncoder().encode(password));
        
        //log.debug("@: encoded password = {}", encodedPassword);
        //log.info("encoded password = {}", encodedPassword);
        //log.debug("@: encoded password = {}", encodedPassword);

        //log.debug("@: bcript encoded password = {}", new BCryptPasswordEncoder().encode(password));

        // Then
        //assertThat(encodedPassword, notNullValue());
    }
   
    
    
    @Test
    public void testBCryptGenerateEncodedPassword() throws Exception {

        // Given
        String password = "1234";

        // When
        String encodedPassword = passwordEncoder.encode(password);
        log.debug("@: encoded password = {}", encodedPassword);
        log.info("encoded password = {}", encodedPassword);
        log.debug("@: encoded password = {}", encodedPassword);

        log.debug("@: bcript encoded password = {}", new BCryptPasswordEncoder().encode(password));

        // Then
        assertThat(encodedPassword, notNullValue());
    }

}
